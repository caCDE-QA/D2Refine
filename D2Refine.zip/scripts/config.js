/* Expose configuration */
var D2RefineExtension = {};
D2RefineExtension.commandPath = "/command/D2Refine/";
